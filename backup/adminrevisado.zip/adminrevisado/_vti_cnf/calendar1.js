vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Feb 2006 15:30:02 -0000
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|admin/registrocombo.asp admin/registrocombo2.asp admin/registro.asp adminrevisado/adminrevisado/admin.asp
vti_author:SR|DELL840-04\\rmontoya
vti_modifiedby:SR|DELL840-04\\rmontoya
vti_timecreated:TR|08 Feb 2006 15:30:02 -0000
